package com.dicoding.imamf.submission3made

class Constants {
    @JvmField var TMDB_API_KEY = "a74218a59b6db4c0403f330bf8f6afec"
}